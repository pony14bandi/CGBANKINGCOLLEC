package com.cg.banking.main;

import com.cg.banking.beans.Customer;
import com.cg.banking.exceptions.*;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args) throws BankingServicesDownException, CustomerNotFoundException, InvalidAmountException, InvalidAccountTypeException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		
		BankingServices bankingServices = new BankingServicesImpl();
		int customerId = bankingServices.acceptCustomerDetails("POORNIMA", "BANDI", "poornima.cg@gmail", "JGDJ7898", "PUNE", "Maharashtra", 401127, "HYDERABAD", "TELANGANA", 502032);
		int customerId1 = bankingServices.acceptCustomerDetails("Dileep", "Kumar", "dil.kumar@gmail","hdfh7589", "Warangal", "Telangana", 75687, "dbhij", "dhuy", 65379);
		long accountNo = bankingServices.openAccount(customerId, "Savings", 10000);
		long accountNo1 =  bankingServices.openAccount(customerId1, "Savings", 20000);
		System.out.println("Customer id="+customerId);
		System.out.println(bankingServices.getCustomerDetails(customerId));
		System.out.println("Account number= "+accountNo);
		int pin = bankingServices.generateNewPin(customerId, accountNo);
		System.out.println("New pin number= "+bankingServices.getAccountDetails(customerId, accountNo).getPinNumber());
		int pin1 = bankingServices.generateNewPin(customerId1, accountNo1);
		System.out.println("New pin number= "+bankingServices.getAccountDetails(customerId1, accountNo1).getPinNumber());
		System.out.println(bankingServices.depositAmount(customerId, accountNo, 1000.10f));
		//System.out.println(bankingServices.withdrawAmount(customerId, accountNo, 5000, pin));
		//System.out.println(bankingServices.fundTransfer(customerId1, accountNo1, customerId, accountNo, 2000, pin));
		//System.out.println(bankingServices.changeAccountPin(customerId, accountNo, pin, pin1));
		//System.out.println(bankingServices.closeAccount(customerId1, accountNo1));
		System.out.println(bankingServices.getAccountAllTransaction(customerId1, accountNo1));	
		
	}
}
		
