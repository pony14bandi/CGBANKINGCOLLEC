package com.cg.banking.exceptions;

@SuppressWarnings("serial")
public class InsufficientAmountException extends Exception {

	public InsufficientAmountException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InsufficientAmountException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InsufficientAmountException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InsufficientAmountException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
